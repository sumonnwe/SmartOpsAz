using DeviceService.Application.Interfaces;
using Microsoft.Extensions.Logging;

namespace DeviceService.Infrastructure.Messaging;

/// <summary>
/// Placeholder event publisher. Replace with MassTransit + RabbitMQ in production.
/// </summary>
public class NoOpEventPublisher : IEventPublisher
{
    private readonly ILogger<NoOpEventPublisher> _logger;

    public NoOpEventPublisher(ILogger<NoOpEventPublisher> logger)
    {
        _logger = logger;
    }

    public Task PublishDeviceOfflineAsync(
        Guid deviceId,
        string deviceCode,
        Guid? linkedAssetId,
        DateTimeOffset lastHeartbeatAtUtc,
        int offlineThresholdSeconds,
        Guid correlationId,
        CancellationToken cancellationToken = default)
    {
        _logger.LogInformation(
            "EVENT: DeviceOffline - DeviceId={DeviceId}, Code={Code}, LastHB={LastHB}, Threshold={Threshold}s",
            deviceId, deviceCode, lastHeartbeatAtUtc, offlineThresholdSeconds);
        return Task.CompletedTask;
    }

    public Task PublishDeviceRecoveredAsync(
        Guid deviceId,
        string deviceCode,
        Guid? linkedAssetId,
        DateTimeOffset lastHeartbeatAtUtc,
        Guid correlationId,
        CancellationToken cancellationToken = default)
    {
        _logger.LogInformation(
            "EVENT: DeviceRecovered - DeviceId={DeviceId}, Code={Code}, LastHB={LastHB}",
            deviceId, deviceCode, lastHeartbeatAtUtc);
        return Task.CompletedTask;
    }
}