namespace DeviceService.Application.Interfaces;

public interface IEventPublisher
{
    Task PublishDeviceOfflineAsync(
        Guid deviceId,
        string deviceCode,
        Guid? linkedAssetId,
        DateTimeOffset lastHeartbeatAtUtc,
        int offlineThresholdSeconds,
        Guid correlationId,
        CancellationToken cancellationToken = default);

    Task PublishDeviceRecoveredAsync(
        Guid deviceId,
        string deviceCode,
        Guid? linkedAssetId,
        DateTimeOffset lastHeartbeatAtUtc,
        Guid correlationId,
        CancellationToken cancellationToken = default);
}